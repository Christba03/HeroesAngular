import { Component } from '@angular/core';

@Component({
  selector: 'app-register-page',
  standalone: false,
  
  templateUrl: './register-page.component.html',
  styles: ``
})
export class RegisterPageComponent {

}
