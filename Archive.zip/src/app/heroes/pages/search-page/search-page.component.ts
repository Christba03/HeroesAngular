import { Component } from '@angular/core';

@Component({
  selector: 'app-search-page',
  standalone: false,
  
  templateUrl: './search-page.component.html',
  styles: ``
})
export class SearchPageComponent {

}
