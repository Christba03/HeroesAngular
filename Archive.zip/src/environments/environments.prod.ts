export const environments = {
    baseURL: 'http://angelrivera.com'
}